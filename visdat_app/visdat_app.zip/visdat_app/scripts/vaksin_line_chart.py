from collections import defaultdict
from bokeh.models import Panel
from bokeh.models import HoverTool, RadioButtonGroup, DateRangeSlider, Button, CheckboxGroup
from bokeh.layouts import Column, Row
from bokeh.models.sources import ColumnDataSource
from bokeh.plotting import figure
from bokeh.palettes import Category20b_20, Category20c_20

def vaksin_line_chart_tabs(vaksin1, vaksin2):
    def make_dataset(data, provinsi, tanggal_awal, tanggal_akhir):
        new_data = defaultdict(list)
        color_list = Category20c_20 + Category20b_20
        for x in provinsi:
            filter_data = data[(data['Tanggal'] >= tanggal_awal) & (data['Tanggal'] <= tanggal_akhir) & (data['Provinsi'] == x)] 
            tanggal = list(filter_data['Tanggal'])
            total = list(filter_data['Total'])
            new_data['Tanggal'].append(tanggal)
            new_data['Total'].append(total)
            new_data['Provinsi'].append(x)
            new_data['colors'].append(color_list[provinsi_awal.index(x)])
        return ColumnDataSource(new_data)

    def style(plot):
        plot.title.align = 'center'
        plot.title.text_font_size = '20pt'
        plot.title.text_font = 'serif'

        plot.xaxis.axis_label_text_font_size = '14pt'
        plot.xaxis.axis_label_text_font_style = 'bold'
        plot.yaxis.axis_label_text_font_size = '14pt'
        plot.yaxis.axis_label_text_font_style = 'bold'

        plot.xaxis.major_label_text_font_size = '12pt'
        plot.yaxis.major_label_text_font_size = '12pt'

        plot.toolbar.active_drag = None

        return plot

    def make_plot(source):
        plot = figure(plot_width = 1000, plot_height = 600, title = 'Vaksin Dosis 1', x_axis_type='datetime', x_axis_label = 'Tanggal', y_axis_label = 'Jumlah Pertambahan Vaksin Dosis 1 (Ribu)')
        plot.multi_line(xs='Tanggal', ys='Total', line_width=3, color='colors', source=source)
        plot.add_tools(HoverTool(show_arrow=False, line_policy='next', tooltips=[
            ('Provinsi', '@Provinsi'),
            ('Tanggal', '$x{%F}'),
            ('Total', '$y{1.11}')
        ], formatters={'$x': 'datetime'}))
        plot = style(plot)
        return plot

    def dummy():
        data_dummy = defaultdict(list)
        data_dummy['Tanggal'].append([tanggal_awal, tanggal_akhir])
        data_dummy['Total'].append([None, None])
        data_dummy['Provinsi'].append(None)
        data_dummy['colors'].append(None)
        return ColumnDataSource(data_dummy)

    def update(attr, old, new):
        if radio.active == 0:
            data = vaksin1
            plot.yaxis.axis_label = 'Jumlah Pertambahan Vaksin Dosis 1 (Ribu)'
        else:
            data = vaksin2
            plot.yaxis.axis_label = 'Jumlah Pertambahan Vaksin Dosis 2 (Ribu)'

        plot.title.text = radio.labels[radio.active]
        provinsi = [checkbox.labels[i] for i in checkbox.active]
        tanggal_awal = slider.value_as_datetime[0]
        tanggal_akhir = slider.value_as_datetime[1]
        new_source = make_dataset(data, provinsi, tanggal_awal, tanggal_akhir)
        if provinsi == []:
            new_source = dummy()
        source.data.update(new_source.data)


    def button_check_click():
        checkbox.active = list(range(len(provinsi_awal)))
    
    def button_uncheck_click():
        checkbox.active = []

    data = vaksin1
    provinsi_awal = list(sorted(set(data['Provinsi'])))

    tanggal_awal = min(data['Tanggal'])
    tanggal_akhir = max(data['Tanggal'])

    radio = RadioButtonGroup(labels=['Vaksin Dosis 1', 'Vaksin Dosis 2'], active=0)
    button_check = Button(label="Check All", button_type="success", default_size=150)
    button_uncheck = Button(label="Uncheck All", button_type="danger", default_size=150)
    slider = DateRangeSlider(title='Tanggal', value=(tanggal_awal, tanggal_akhir),  start=tanggal_awal, end=tanggal_akhir)
    checkbox = CheckboxGroup(labels=provinsi_awal, active=list(range(len(provinsi_awal))))

    source = make_dataset(data, provinsi_awal, tanggal_awal, tanggal_akhir)
    plot = make_plot(source)

    button_check.on_click(button_check_click)
    button_uncheck.on_click(button_uncheck_click)
    radio.on_change('active', update)
    slider.on_change('value', update)
    checkbox.on_change('active', update)
    widgets = Column(radio, slider, Row(button_check, button_uncheck), checkbox)
    layout = Row(widgets, plot)
    tab = Panel(child=layout, title='Line Chart Vaksin')
    return tab
