import pandas as pd
from os.path import dirname, join
from bokeh.io import curdoc
from bokeh.models.widgets import Tabs
from scripts.vaksin_line_chart import vaksin_line_chart_tabs
from scripts.covid import covid_tabs

vaksin1_series = pd.read_csv(join(dirname(__file__), 'data', 'vaksin1_series.csv'), parse_dates=['Tanggal'])
vaksin2_series = pd.read_csv(join(dirname(__file__), 'data', 'vaksin2_series.csv'), parse_dates=['Tanggal'])
covid = pd.read_csv(join(dirname(__file__), 'data', 'covid.csv'), parse_dates=['Date'])

tab1 = covid_tabs(covid)
tab2 = vaksin_line_chart_tabs(vaksin1_series, vaksin2_series)
tabs = Tabs(tabs = [tab1, tab2])

curdoc().add_root(tabs)


